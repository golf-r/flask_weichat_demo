# -*- coding: utf-8 -*-

import os
from sqlite3 import dbapi2 as sqlite3
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash, make_response
from contextlib import closing
import urllib
import json
import hashlib
import time
import xml.etree.ElementTree as ET

# 创建应用
app = Flask(__name__)

# 对应用进行配置
app.config.update(dict(
    DATABASE=os.path.join(app.root_path, 'flaskr.db')   
))
app.config.from_envvar('FLASKR_SETTINGS', silent=True)

#数据库连接
def connect_db():
    """Connects to the specific database."""
    rv = sqlite3.connect(app.config['DATABASE'])
    rv.row_factory = sqlite3.Row
    return rv
#数据库初始化
def init_db():
    """Initializes the database."""
    with closing(connect_db()) as db:
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()
#微信指定的文本消息回复格式
xml_rep =   '''
            <xml><ToUserName><![CDATA[%s]]></ToUserName>
            <FromUserName><![CDATA[%s]]></FromUserName>
            <CreateTime>%s</CreateTime><MsgType><![CDATA[text]]></MsgType>
            <Content><![CDATA[%s]]></Content></xml>
            '''
#微信连接服务器验证
def weixin_verify():
    signature = request.args.get('signature')
    timestamp = request.args.get('timestamp')
    nonce = request.args.get('nonce')
    echostr = request.args.get('echostr')

    token = 'test'  # 和申请消息接口时的Token一致
    tmplist = [token, timestamp, nonce]
    tmplist.sort()
    tmpstr = ''.join(tmplist)
    hashstr = hashlib.sha1(tmpstr).hexdigest()

    if hashstr == signature:
        return echostr  # success
    return 'access verification fail'  # fail
#消息回复
def weixin_response():
    rec = request.stream.read()
    xml_rec = ET.fromstring(rec)
    tou = xml_rec.find('ToUserName').text
    fromu = xml_rec.find('FromUserName').text
    content = xml_rec.find('Content').text
    #此处可以与第三方api对接实现更多的功能
	if content == u"后台":
        content = 'http://shichen007.pythonanywhere.com/'
    else:
        content = '正在开发中...'
    response = make_response(xml_rep % (fromu, tou, str(int(time.time())), content))
    response.content_type = 'application/xml'
    return response

@app.before_request
def before_request():
    g.db = connect_db()

@app.teardown_request
def teardown_request(exception):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()
#微信接口绑定为/weixin
@app.route('/weixin',methods=['GET','POST'])
def weixin():
    response = None
    if request.method == 'GET':
        response = weixin_verify()
    else:
        response = weixin_response()
    return response


#注册界面URL绑定
@app.route('/test', methods=['GET', 'POST'])
def test():
    if request.method == 'POST':
        g.db.execute('insert into test (name, id_num, address, phone_num, remark) values (?, ?, ?, ?, ?)',
                     [request.form['name'], request.form['id_num'], request.form['address'], request.form['phone_num'], request.form['remark']])
        g.db.commit()
       return render_template('msg-success.html')
    return render_template('test.html')