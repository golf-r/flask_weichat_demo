drop table if exists entries;
create table entries (
  id integer primary key autoincrement,
  title text,
  'text' text
);
drop table if exists test;
create table test (
  id integer primary key autoincrement,
  name text not null,
  id_num integer not null,
  address text not null,
  phone_num integer not null,
  remark text
);